﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    public class Book
    {
        int book_id;
        string title;
        string author;
        string description;
        string isbn;
        string edition;
        int total_copies;
        int available_copies;

        public Book()
        {
            book_id = 0;
            title = "";
            author = "";
            description = "";
            isbn = "";
            edition = "";
            total_copies = 0;
            available_copies = 0;
        }

        public int Book_id
        {
            get { return book_id; }
            set { book_id = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string ISBN
        {
            get { return isbn; }
            set { isbn = value; }
        }

        public string Edition
        {
            get { return edition; }
            set { edition = value; }
        }

        public int Total_Copies
        {
            get { return total_copies; }
            set { total_copies = value; }
        }

        public int Available_Copies
        {
            get { return available_copies; }
            set { available_copies = value; }
        }
    }
}

