﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class BookBorrowing
    {
        public BookBorrowing() { }
        public void borrowBook(Record b)
        {
            DAL d = new DAL();
            //d.borrowBook(b);
        }

        public void returnBook(Record b)
        {
            DAL d = new DAL();
            //if (d.isBookBorrowed(b.Book_id, b.Borrowed_By))
            //{
            //    d.returnBook(b);
            //}
        }

        public void viewBorrowerHistory()
        {

        }
    }
}
