﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    public class ManageBooks
    {
        List<Book> books = new List<Book>();
        int book_count;
        public ManageBooks()
        {
            book_count = 0;
        }

        public List<Book> Books
        {
            get { return books; }
            set { books = value; }
        }

        // Add new book to the collection
        public void addBook(Book b)
        {
            string isbn = b.ISBN;
            DAL d = new DAL();
            if (!d.isBookAvailable(isbn)) //check if book not already avaiable 
            {
                int bookid = d.insertBook(b);
                if (bookid != 0)
                {
                    Console.WriteLine("\nBook Successfully Added - The ID Assigned is: " + bookid);
                }
                else
                {
                    Console.WriteLine("\nFailed to insert the book.");
                }
            }
            else
            {
                System.Console.WriteLine("\nThe book already Exists with this isbn number");
            }
        }

        public bool isBookAvailable(int id) //Search book on the basis of ID
        {
            DAL d = new DAL();
            return d.isBookAvailable(id);
        }

        public Book getBook(int id) 
        {
            DAL d = new DAL();
            return d.getBook(id);
        }
        public void deleteBook(int id)
        {
            DAL d = new DAL();
            int rows = d.deleteBook(id);
            if (rows > 0)
            {
                Console.WriteLine("Book Deleted Successfully!");
            }
        }

        public void updateBook(Book b)
        {
            DAL d = new DAL();
            int rows = d.updateBook(b);
            if (rows > 0)
            {
                Console.WriteLine("Book Information has been Successfully Updated!");
            }
            else
            {
                Console.WriteLine("Book Information not Updated!");

            }
        }

        public List<Book> searchBooks(Book b) //Search books on the basis of provided information and returns list of books
        {
            DAL d = new DAL();
            List<Book> books = d.searchBooks(b);
            return books;

        }

        /*
        public void viewReports(string startingDate, String endingDate)//search table and return list of reports
        {
            LMS_DA d = new LMS_DA();
            d.viewReports(startingDate, endingDate);
        }
        */
    }
}

