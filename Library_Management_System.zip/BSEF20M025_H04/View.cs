﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    public class View
    {
        public View() { }

        public void View_Menu()
        {
            bool choice = true;

            while (choice)
            {
                Console.WriteLine("\n");
                Console.WriteLine("\t\t\t------------------------------------------------------");
                Console.WriteLine("\t\t\t\tWELCOME TO LMS");
                Console.WriteLine("\t\t\t------------------------------------------------------");
                Console.WriteLine("\n");
                Console.WriteLine("\t\t\t1. Manage Books");
                Console.WriteLine("\t\t\t2. Manage Book Borrowings");
                Console.Write("\t\t\tSelect an option: ");
                Console.ForegroundColor = ConsoleColor.Green;
                int option = Convert.ToInt32(Console.ReadLine());
                Console.ResetColor();

                Console.WriteLine('\n');
                if (option == 1)
                {
                    bool ch = true;
                    while (ch)
                    {
                        Console.WriteLine(" 1. Add New Book");
                        Console.WriteLine(" 2. Delete Existing Book");
                        Console.WriteLine(" 3. Update Book Information");
                        Console.WriteLine(" 4. Search For Books");
                        Console.WriteLine(" 5. View Reports");
                        Console.WriteLine(" 6. Exit");

                        Console.Write(" Select an option: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        int opt = Convert.ToInt32(Console.ReadLine());
                        Console.ResetColor();

                        Console.Write("\n");


                        if (opt == 1)
                        {
                            Book book = new Book();
                            ManageBooks m = new ManageBooks();

                            //Ask for book details and make an object of Book

                            Console.Write(" Title: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string title = Console.ReadLine();
                            book.Title = title;
                            Console.ResetColor();


                            Console.Write(" Author: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string author = Console.ReadLine();
                            book.Author = author;
                            Console.ResetColor();

                            Console.Write(" Description: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string des = Console.ReadLine();
                            book.Description = des;
                            Console.ResetColor();

                            Console.Write(" ISBN: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string isbn = Console.ReadLine();
                            Console.ResetColor();
                            while (isbn.Length != 13)
                            {
                                Console.WriteLine("\nInvalid ISBN! \n ISBN should be 13 digits long");
                                Console.Write(" ISBN: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                isbn = Console.ReadLine();
                                Console.ResetColor();

                            }
                            book.ISBN = isbn;

                            Console.Write(" Edition: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string edition = Console.ReadLine();
                            book.Edition = edition;
                            Console.ResetColor();


                            Console.Write(" Number of Books: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            int total = Convert.ToInt32(Console.ReadLine());
                            book.Total_Copies = total;
                            Console.ResetColor();

                            Console.Write(" Available Copies: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            int copies = Convert.ToInt32(Console.ReadLine());
                            book.Available_Copies = copies;
                            Console.ResetColor();

                            m.addBook(book);
                        }

                        else if (opt == 2)
                        {

                            Console.Write(" Enter id of book you want to delete: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            int bookid = Convert.ToInt32(Console.ReadLine());
                            Console.ResetColor();

                            Book book = new Book();
                            ManageBooks m = new ManageBooks();

                            if (m.isBookAvailable(bookid))
                            {
                                book = m.getBook(bookid);
                                if (book.Book_id != 0)
                                {
                                    Console.WriteLine($"You wish to delete the {book.Edition}th edition of book {book.Title} by {book.Author}");
                                    Console.Write(" Re-Enter id of book to confirm delete: ");
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    bookid = Convert.ToInt32(Console.ReadLine());
                                    Console.ResetColor();
                                    m.deleteBook(bookid);
                                }

                            }
                            else
                            {
                                Console.Write("\nBook Not Found!");

                            }

                        }

                        else if (opt == 3)
                        {
                            //Make objects to store old information of book and new information of book
                            Book oldbook = new Book();
                            Book newbook = new Book();
                            ManageBooks m = new ManageBooks();

                            Console.Write(" Enter id of book you want to update: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            int bookid = Convert.ToInt32(Console.ReadLine());
                            Console.ResetColor();

                            //Search for book of given id and display its information
                            if (!m.isBookAvailable(bookid))
                            {
                                Console.Write("Book Not Found");
                            }
                            else
                            {
                                oldbook = m.getBook(bookid);
                                Console.Write($" Book_id: {oldbook.Book_id}\n");
                                Console.Write($" Title: {oldbook.Title}\n");
                                Console.Write($" Author: {oldbook.Author}\n");
                                Console.Write($" Description: {oldbook.Description}\n");
                                Console.Write($" ISBN: {oldbook.ISBN}\n");
                                Console.Write($" Edition: {oldbook.Edition}\n");
                                Console.Write($" Total Copies: {oldbook.Total_Copies}\n");
                                Console.Write($" Available Copies: {oldbook.Available_Copies}\n");

                                //Ask for book details and make an object of Book
                                Console.Write("\nPlease enter the fields you wish to update (leave blank otherwise):\n");
                                Console.Write(" Title: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                string title = Console.ReadLine();
                                if (!string.IsNullOrEmpty(title))
                                {
                                    newbook.Title = title;

                                }
                                Console.ResetColor();


                                Console.Write(" Author: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                string author = Console.ReadLine();
                                if (!string.IsNullOrEmpty(author))
                                {
                                    newbook.Author = author;

                                }

                                Console.ResetColor();

                                Console.Write(" Description: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                string des = Console.ReadLine();
                                if (!string.IsNullOrEmpty(des))
                                {
                                    newbook.Description = des;

                                }
                                Console.ResetColor();

                                Console.Write(" ISBN: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                string isbn = Console.ReadLine();
                                Console.ResetColor();
                                if (!string.IsNullOrEmpty(isbn))
                                {
                                    while (isbn.Length != 13)
                                    {
                                        Console.WriteLine("\nInvalid ISBN! \n ISBN should be 13 digits long");
                                        Console.Write(" ISBN: ");
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        isbn = Console.ReadLine();
                                    }
                                    newbook.ISBN = isbn;

                                }
                                else
                                {
                                    //
                                }


                                Console.Write(" Edition: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                string edition = Console.ReadLine();
                                if (!string.IsNullOrEmpty(edition))
                                {
                                    newbook.Edition = edition;

                                }
                                Console.ResetColor();


                                Console.Write(" Number of Books: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                int total = Convert.ToInt32(Console.ReadLine());
                                if ((total!=0))
                                {
                                    newbook.Total_Copies = total;

                                }
                                Console.ResetColor();

                                Console.Write(" Available Copies: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                int copies = Convert.ToInt32(Console.ReadLine());
                                if (copies!=0)
                                {
                                    newbook.Available_Copies = oldbook.Total_Copies - oldbook.Available_Copies;
                                    newbook.Available_Copies = newbook.Total_Copies - newbook.Available_Copies;
                                }
                  
                                else
                                {
                                    newbook.Available_Copies = copies;

                                }
                                Console.ResetColor();



                                //Update Book Infromation
                                newbook.Book_id = oldbook.Book_id;
                                m.updateBook(newbook);
                            }
                        }

                        else if (opt == 4)
                        {
                            //Make an object of book on the basis of which books will be found
                            Book book = new Book();
                            Console.Write("\nSEARCH MENU\n");

                            //Collect Book Details

                            Console.Write(" Book id: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string id = Console.ReadLine();
                            if (id != "")
                            {
                                book.Book_id = Convert.ToInt32(id);

                            }
                            Console.ResetColor();

                            Console.Write(" Title: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string title = Console.ReadLine();
                            book.Title = title;
                            Console.ResetColor();


                            Console.Write(" Author: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string author = Console.ReadLine();
                            book.Author = author;
                            Console.ResetColor();

                            Console.Write(" Description: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string des = Console.ReadLine();
                            book.Description = des;
                            Console.ResetColor();

                            Console.Write(" ISBN: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string isbn = Console.ReadLine();
                            Console.ResetColor();
                            if (isbn == "")
                            {
                                book.ISBN = isbn;

                            }
                            else
                            {
                                while (isbn.Length != 13)
                                {
                                    Console.WriteLine("\nInvalid ISBN! \n ISBN should be 13 digits long");
                                    Console.Write(" ISBN: ");
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    isbn = Console.ReadLine();
                                }
                            }


                            Console.Write(" Edition: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string edition = Console.ReadLine();
                            book.Edition = edition;
                            Console.ResetColor();


                            Console.Write(" Total Copies: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string total = Console.ReadLine();
                            if (total != "")
                            {
                                book.Total_Copies = Convert.ToInt32(total);

                            }
                            Console.ResetColor();

                            Console.Write(" Available Copies: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string copies = Console.ReadLine();
                            if (total != "")
                            {
                                book.Available_Copies = Convert.ToInt32(copies);
                            }
                            Console.ResetColor();

                            //Search For books and get list of books
                            List<Book> books = new List<Book>();
                            ManageBooks m = new ManageBooks();
                            books = m.searchBooks(book);

                            if (books.Count != 0)
                            {
                                Console.Write("\tBook_Id\tTitle\tAuthor\tEdition\tTotal Copies\tAvailable Copies");
                                foreach (Book b in books)
                                {
                                    Console.Write($"\t{b.Book_id}\t{b.Title}\t{b.Author}\t{b.Edition}\t{b.Total_Copies}\t{b.Available_Copies}\n");
                                }

                            }
                        }

                        else if (opt == 5)
                        {
            
                        }

                        else if (opt == 6)
                        {
                            ch = false;
                        }
                    }

                }

                else if (option == 2)
                {
                    bool ch = true;

                    while (ch)
                    {
                        Console.WriteLine(" 1. Borrow Book");
                        Console.WriteLine(" 2. Return Book");
                        Console.WriteLine(" 3. View Browser History");
                        Console.WriteLine(" 4. Exit");

                        Console.Write(" Select an option: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        int opt2 = Convert.ToInt32(Console.ReadLine());
                        Console.ResetColor();

                        Console.Write("\n");

                        if (opt2 == 1)
                        {
                            BookBorrowing bb=new BookBorrowing();
                            //bb.borrowBook();

                        }
                        else if (opt2 == 2)
                        {
                            BookBorrowing bb = new BookBorrowing();
                            //bb.returnBook();

                        }
                        else if (opt2 == 3)
                        {
                            BookBorrowing bb = new BookBorrowing();
                            bb.viewBorrowerHistory();
                        }
                        else if (opt2 == 4)
                        {
                            ch=false;
                        }

                    }
                   
                       
                }

                else
                {
                    choice = false;
                }
            }

        }
    }
}

