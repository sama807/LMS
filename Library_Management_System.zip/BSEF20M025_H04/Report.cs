﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    public class Report
    {
        string title;
        string author;
        string edition;
        string borrowed_by;
        string borrowed_date;
        string return_date;
        int fine;
        string fine_status;

        public Report()
        {
            title = "";
            author = "";
            edition = "";
            borrowed_by = string.Empty;
            borrowed_date = string.Empty;
            return_date = string.Empty;
            fine = 0;
            fine_status = "";
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        public string Edition
        {
            get { return edition; }
            set { edition = value; }
        }

        public string Borrowed_By
        {
            get { return borrowed_by; }
            set { borrowed_by = value; }
        }

        public string Borrowed_Date
        {
            get { return borrowed_date; }
            set { borrowed_date = value; }
        }

        public string Return_Date
        {
            get { return return_date; }
            set { return_date = value; }
        }

        public int Fine
        {
            get { return fine; }
            set { fine = value; }
        }
        public string Fine_status
        {
            get { return fine_status; }
            set { fine_status = value; }
        }
    }
}
