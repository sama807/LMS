﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace Library_Management_System
{
    public class DAL
    {
        public DAL() { }

        public bool isBookAvailable(String isbn)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            //To Run Query
            string query = $"select * from Book where ISBN = '{isbn}' ";

            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            //Console.WriteLine(dr.Read());

            if (dr.Read())
            {
                return true;
            }
            return false;
        }

        public bool isBookAvailable(int id) //Search book on the basis of ID
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            //To Run Query
            string query = $"select * from Book where Id = {id} ";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                return true;
            }
            return false;
        }

        public Book getBook(int id)  
        {
            Book b = new Book();

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            //To Run Query
            string query = $"select * from Book where Id = '{id}' ";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                b.Book_id = dr.GetInt32(dr.GetOrdinal("Id"));
                b.Title = dr.GetString(dr.GetOrdinal("Title"));
                b.Author = dr.GetString(dr.GetOrdinal("Author"));
                b.Description = dr.GetString(dr.GetOrdinal("Description"));
                b.ISBN = dr.GetString(dr.GetOrdinal("ISBN"));
                b.Edition = dr.GetString(dr.GetOrdinal("Edition"));
                b.Total_Copies = dr.GetInt32(dr.GetOrdinal("TotalCopies"));
                b.Available_Copies = dr.GetInt32(dr.GetOrdinal("AvailableCopies"));
            }

            return b;
        }
        public int insertBook(Book b)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connectionString);
            int Id = 0;
           
            con.Open();
            string insertQuery = $"INSERT INTO Book (Title, Author, Description, ISBN, Edition, TotalCopies, AvailableCopies)  OUTPUT INSERTED.Id VALUES('{b.Title}','{b.Author}','{b.Description}','{b.ISBN}','{b.Edition}',{b.Total_Copies},{b.Available_Copies})";
            SqlCommand command = new SqlCommand(insertQuery, con);

            Id = (int)command.ExecuteScalar();
            //int rowsAffected = command.ExecuteNonQuery();
            //Console.WriteLine($"{rowsAffected} row(s) inserted In Driver.");
            //Console.WriteLine($"Book ID: {Id}");

            return Id;

        }

        public int deleteBook(int id)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string sqlQuery = $"DELETE FROM book WHERE Id = {id}";
            SqlCommand command = new SqlCommand(sqlQuery, con);
            int rowsAffected = command.ExecuteNonQuery();
            return rowsAffected;
        }
        public int updateBook(Book b)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string sqlQuery = $"UPDATE Book SET Title = '{b.Title}', Author = '{b.Author}', Description = '{b.Description}', ISBN='{b.ISBN}', Edition='{b.Edition}',TotalCopies={b.Total_Copies},AvailableCopies={b.Available_Copies}  WHERE Id = {b.Book_id}";
            SqlCommand command = new SqlCommand(sqlQuery, con);

            int rowsAffected = command.ExecuteNonQuery();
            return rowsAffected;
        }

        public List<Book> searchBooks(Book book)
        {
            List<Book> books = new List<Book>();
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Prepare the SELECT query with conditions
                string sqlQuery = "SELECT * FROM Book WHERE 1 = 1";
                SqlCommand command = new SqlCommand(sqlQuery, connection);

                if (book.Book_id != 0)
                {
                    sqlQuery += $" AND Book_id = {book.Book_id}";
                }

                if (!string.IsNullOrEmpty(book.Title))
                {
                    sqlQuery += $" AND Title = '{book.Title}'";
                }

                if (!string.IsNullOrEmpty(book.Author))
                {
                    sqlQuery += $" AND Author = '{book.Author}";
                }

                if (!string.IsNullOrEmpty(book.Description))
                {
                    sqlQuery += $" AND Description = '{book.Description}'";
                }

                if (!string.IsNullOrEmpty(book.ISBN))
                {
                    sqlQuery += $" AND ISBN = '{book.ISBN}";
                }

                if (!string.IsNullOrEmpty(book.Edition))
                {
                    sqlQuery += $" AND Edition = '{book.Edition}'";
                }

                if (book.Total_Copies != 0)
                {
                    sqlQuery += $" AND TotalCopies = {book.Total_Copies}";
                }

                if (book.Available_Copies != 0)
                {
                    sqlQuery += $" AND AvailableCopies = {book.Available_Copies}";
                }

                command.CommandText = sqlQuery;

                using (SqlDataReader reader = command.ExecuteReader())
                {

                    while (reader.Read())
                    {
                        int bookId = reader.GetInt32(reader.GetOrdinal("Id"));
                        string bookTitle = reader.GetString(reader.GetOrdinal("Title"));
                        string bookAuthor = reader.GetString(reader.GetOrdinal("Author"));
                        string bookDescription = reader.GetString(reader.GetOrdinal("Description"));
                        string isbn = reader.GetString(reader.GetOrdinal("ISBN"));
                        string edition = reader.GetString(reader.GetOrdinal("Edition"));
                        int total = reader.GetInt32(reader.GetOrdinal("TotalCopies"));
                        int available = reader.GetInt32(reader.GetOrdinal("AvaialableCopies"));

                        //Create an object of book
                        Book b = new Book();
                        b.Book_id = bookId;
                        b.Title = bookTitle;
                        b.Author = bookAuthor;
                        b.Description = bookDescription;
                        b.ISBN = isbn;
                        b.Edition = edition;
                        b.Available_Copies = available;
                        b.Total_Copies = total;

                        //Add new book to the list
                        books.Add(b);
                    }
                }
            }

            return books;
        }

        /*
        public void viewReports(string startingDate, String endingDate) // Search data from table book and
        {                                                               // return list of reports

        }

        public void borrowBook(BorrowingRecord b)
        {

        }

        public bool isBookBorrowed(int book_id, String borrower)// checks if book is borrowed 
        {                                            // on basis of id and borrower
            return false;
        }

        public void returnBook(BorrowingRecord b)//update information of book and borrowed book
        {

        }
        */
    }
}
